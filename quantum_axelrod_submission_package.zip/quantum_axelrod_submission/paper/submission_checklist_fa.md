# چک‌لیست قبل از ارسال به JOSS

- [ ] نام نویسندگان و affiliations تکمیل شود.
- [ ] ORCID نویسنده‌ها وارد شود.
- [ ] مخزن عمومی GitHub/GitLab ساخته شود.
- [ ] `README.md` با نصب، مثال و citation کامل شود.
- [ ] `LICENSE` نهایی شود؛ MIT فعلاً گذاشته شده است.
- [ ] تست‌ها با `pytest` پاس شوند.
- [ ] GitHub Actions یا CI مشابه اضافه شود.
- [ ] documentation یا حداقل API usage examples اضافه شود.
- [ ] یک release رسمی ساخته شود.
- [ ] release در Zenodo آرشیو و DOI گرفته شود.
- [ ] DOI و repository URL در `paper/paper.md` وارد شود.
- [ ] ادعای full Axelrod catalog فقط زمانی اضافه شود که adapter کامل و benchmark کامل انجام شده باشد.
