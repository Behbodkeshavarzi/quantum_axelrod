Dear JOSS Editors,

We are submitting QAxelrod, a Python package that provides a quantum-game execution layer for Axelrod-style Iterated Prisoner's Dilemma simulations. The software separates classical policy logic from quantum execution operators, enabling reproducible experiments with EWL-style entanglement, local quantum noise, repeated matches, round-robin tournaments, and reference evolutionary calculations.

The package addresses a methodological gap between classical Axelrod tournament software and quantum game theory examples. It includes tests for probability normalization, exact classical recovery under the classical lift, and entangler behavior, together with scripts that regenerate the example data and figures included in the paper.

The repository is open source under the MIT License and includes documentation, tests, example scripts, and the JOSS-format paper.

Sincerely,

[Corresponding author name]
