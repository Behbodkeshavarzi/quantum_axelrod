# Revision log

## Internal review round 1: technical correctness
- Rejected the original `ZZ` entangler because it does not entangle `|0...0>`.
- Replaced it with a GHZ-type EWL entangler.
- Corrected the EWL defection operator.
- Added explicit classical recovery discussion.

## Internal review round 2: claims and scope
- Removed unsupported claims of exhaustive 230+ strategy benchmarking.
- Reframed the paper as a reproducible software/methodology contribution.
- Added limitations and future work.

## Internal review round 3: reproducibility
- Created Python package structure.
- Added tests.
- Added figure and CSV reproduction script.
- Regenerated figures and results from code.

## Internal review round 4: journal fit
- Prepared a JOSS-format `paper.md`.
- Preserved a full LaTeX manuscript for preprint or later theory submission.
- Added Persian reviewer report and submission checklist.
